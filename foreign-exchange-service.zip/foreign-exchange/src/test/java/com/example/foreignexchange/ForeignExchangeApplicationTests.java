package com.example.foreignexchange;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ForeignExchangeApplicationTests {

    @Test
    void contextLoads() {
    }

}
