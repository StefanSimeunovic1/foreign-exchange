package com.example.foreignexchange.application.service.order;

import com.example.foreignexchange.adapter.out.order.OrderJpaMapper;
import com.example.foreignexchange.domain.contracts.order.GetAllOrdersContract;
import com.example.foreignexchange.domain.entity.Order;
import com.example.foreignexchange.domain.ports.order.GetAllOrdersPort;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;

@AllArgsConstructor
@Component
public class GetAllOrdersService implements GetAllOrdersContract {

    private OrderJpaMapper orderJpaMapper;
    private GetAllOrdersPort getAllOrdersPort;

    @Override
    public List<Order> getAllOrders() {
        return getAllOrdersPort.getAllOrders();
    }
}
