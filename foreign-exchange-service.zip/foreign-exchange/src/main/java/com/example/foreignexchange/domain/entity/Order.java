package com.example.foreignexchange.domain.entity;

import java.time.LocalDate;

public class Order {

    private Long id;
    private Double surchargePercentage;
    private Double surchargeAmount;
    private Double purchasedAmount;
    private Double paidAmount;
    private Double discountPercentage;
    private Double discountAmount;
    private Double exchangeRate;
    private LocalDate creationDate;
    private Currency purchasedCurrency;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Double getSurchargePercentage() {
        return surchargePercentage;
    }

    public void setSurchargePercentage(Double surchargePercentage) {
        this.surchargePercentage = surchargePercentage;
    }

    public Double getSurchargeAmount() {
        return surchargeAmount;
    }

    public void setSurchargeAmount(Double surchargeAmount) {
        this.surchargeAmount = surchargeAmount;
    }

    public Double getPurchasedAmount() {
        return purchasedAmount;
    }

    public void setPurchasedAmount(Double purchasedAmount) {
        this.purchasedAmount = purchasedAmount;
    }

    public Double getPaidAmount() {
        return paidAmount;
    }

    public void setPaidAmount(Double paidAmount) {
        this.paidAmount = paidAmount;
    }

    public Double getDiscountPercentage() {
        return discountPercentage;
    }

    public void setDiscountPercentage(Double discountPercentage) {
        this.discountPercentage = discountPercentage;
    }

    public Double getDiscountAmount() {
        return discountAmount;
    }

    public void setDiscountAmount(Double discountAmount) {
        this.discountAmount = discountAmount;
    }

    public Double getExchangeRate() {
        return exchangeRate;
    }

    public void setExchangeRate(Double exchangeRate) {
        this.exchangeRate = exchangeRate;
    }

    public LocalDate getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(LocalDate creationDate) {
        this.creationDate = creationDate;
    }

    public Currency getPurchasedCurrency() {
        return purchasedCurrency;
    }

    public void setPurchasedCurrency(Currency purchasedCurrency) {
        this.purchasedCurrency = purchasedCurrency;
    }

    public Order(Double surchargePercentage, Double surchargeAmount, Double purchasedAmount, Double paidAmount, Double discountPercentage, Double discountAmount, Double exchangeRate, Currency purchasedCurrency) {
        this.surchargePercentage = surchargePercentage;
        this.surchargeAmount = surchargeAmount;
        this.purchasedAmount = purchasedAmount;
        this.paidAmount = paidAmount;
        this.discountPercentage = discountPercentage;
        this.discountAmount = discountAmount;
        this.exchangeRate = exchangeRate;
        this.purchasedCurrency = purchasedCurrency;
    }
}
