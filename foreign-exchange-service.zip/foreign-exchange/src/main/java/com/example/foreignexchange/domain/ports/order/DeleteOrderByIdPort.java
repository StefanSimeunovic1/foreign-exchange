package com.example.foreignexchange.domain.ports.order;

public interface DeleteOrderByIdPort {
    void deleteById(int id);
}
