package com.example.foreignexchange.domain.ports.currency;

public interface DeleteCurrencyByIdPort {
    void deleteById(int id);
}
