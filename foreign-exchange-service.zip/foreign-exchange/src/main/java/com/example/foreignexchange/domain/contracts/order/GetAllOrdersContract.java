package com.example.foreignexchange.domain.contracts.order;

import com.example.foreignexchange.domain.entity.Order;

import java.util.List;

public interface GetAllOrdersContract {

    List<Order> getAllOrders();
}
