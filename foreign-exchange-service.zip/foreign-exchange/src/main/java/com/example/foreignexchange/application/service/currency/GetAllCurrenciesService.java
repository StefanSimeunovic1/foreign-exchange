package com.example.foreignexchange.application.service.currency;

import com.example.foreignexchange.adapter.out.currency.CurrencyJpaMapper;
import com.example.foreignexchange.domain.contracts.currency.GetAllCurrenciesContract;
import com.example.foreignexchange.domain.entity.Currency;
import com.example.foreignexchange.domain.ports.currency.GetAllCurrenciesPort;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;

@AllArgsConstructor
@Component
public class GetAllCurrenciesService implements GetAllCurrenciesContract {

    private GetAllCurrenciesPort getAllCurrenciesPort;

    @Override
    public List<Currency> getAllCurrencies() {
        return getAllCurrenciesPort.getAllCurrencies();
    }
}
