package com.example.foreignexchange.domain.contracts.currencyRates;

import com.example.foreignexchange.domain.entity.CurrencyRates;
import java.util.List;

public interface GetAllCurrencyRatesContract {
    List<CurrencyRates> getAll();
}
