package com.example.foreignexchange.adapter.in;

import com.example.foreignexchange.domain.contracts.SendMailContract;
import com.example.foreignexchange.domain.contracts.currency.GetAllCurrenciesContract;
import com.example.foreignexchange.domain.entity.Currency;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.List;

@RestController
@AllArgsConstructor
@CrossOrigin
@RequestMapping("/currencies/")
public class CurrencyController {

    private GetAllCurrenciesContract getAllCurrenciesContract;
    private SendMailContract sendMailContract;

    @GetMapping(path = "getAll")
    public List<Currency> getAllRoles(){
        return getAllCurrenciesContract.getAllCurrencies();
    }
}
