package com.example.foreignexchange.domain.contracts.order;

public interface DeleteOrderByIdContract {
    void deleteById(int id);
}
