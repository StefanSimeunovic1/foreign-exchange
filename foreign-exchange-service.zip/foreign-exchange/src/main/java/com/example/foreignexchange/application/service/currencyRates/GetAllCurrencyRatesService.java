package com.example.foreignexchange.application.service.currencyRates;

import com.example.foreignexchange.domain.contracts.currencyRates.GetAllCurrencyRatesContract;
import com.example.foreignexchange.domain.entity.CurrencyRates;
import com.example.foreignexchange.domain.ports.currencyRates.GetAllCurrencyRatesPort;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;

@AllArgsConstructor
@Component
public class GetAllCurrencyRatesService implements GetAllCurrencyRatesContract {

    private GetAllCurrencyRatesPort getAllCurrencyRatesPort;

    @Override
    public List<CurrencyRates> getAll() {
        return getAllCurrencyRatesPort.getAll();
    }
}
