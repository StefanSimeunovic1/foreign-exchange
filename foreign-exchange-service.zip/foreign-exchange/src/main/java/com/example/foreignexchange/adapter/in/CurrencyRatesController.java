package com.example.foreignexchange.adapter.in;

import com.example.foreignexchange.domain.contracts.currencyRates.GetAllCurrencyRatesContract;
import com.example.foreignexchange.domain.contracts.currencyRates.UpdateCurrencyRatesContract;
import com.example.foreignexchange.domain.entity.CurrencyRates;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@AllArgsConstructor
@CrossOrigin
@RequestMapping("/currency-rates/")
public class CurrencyRatesController {

    private GetAllCurrencyRatesContract getAllCurrencyRatesContract;
    private UpdateCurrencyRatesContract updateCurrencyRatesContract;

    @GetMapping(path = "getAll")
    public List<CurrencyRates> getAll(){
        return getAllCurrencyRatesContract.getAll();
    }

    @PutMapping(path = "updateRates")
    public void update(@RequestBody CurrencyRates currencyRates){
        updateCurrencyRatesContract.updateCurrencyRate(currencyRates);
    }
}
