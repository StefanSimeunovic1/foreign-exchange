package com.example.foreignexchange.domain.contracts;

public interface SendMailContract {
    void SendMail(String body, String topic);
}
