package com.example.foreignexchange.adapter.in;

import com.example.foreignexchange.domain.contracts.SendMailContract;
import com.example.foreignexchange.domain.contracts.order.SaveOrderContract;
import com.example.foreignexchange.domain.entity.Order;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@AllArgsConstructor
@CrossOrigin
@RequestMapping("/orders/")
public class OrderController {

    private SaveOrderContract saveOrderContract;
    private SendMailContract sendMailContract;
    private final String GBP_CURRENCY = "GBP";

    @PostMapping(path = "save")
    public void save(@RequestBody Order order){
        saveOrderContract.save(order);
        sendMail(order);
    }

    private void sendMail(Order order){
        if (order.getPurchasedCurrency().getAbbreviation().equals(GBP_CURRENCY)) {
            StringBuilder sb = new StringBuilder();
            sb.append("Hello, here's are your order details");
            sb.append("Purchased currency:" + order.getPurchasedCurrency().getName());
            sb.append("\n");
            sb.append("Amount of purchased currency:" + order.getPurchasedAmount());
            sb.append("\n");
            sb.append("Paid amount:" + order.getPaidAmount());
            sb.append("\n");
            sb.append("Best regards");
            sb.append("\n");
            sb.append("Thank you for choosing us.");
            sendMailContract.SendMail(sb.toString(), "Order details");
        }
    }
}
