package com.example.foreignexchange.application.service;

import com.example.foreignexchange.domain.contracts.SendMailContract;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Component;

@Component
public class SendMailService implements SendMailContract {

    final JavaMailSender javaMailSender;
    final String MAIL_FROM = "simeunovics47@gmail.com";
    final String MAIL_TO = "simeunovics47@gmail.com";

    @Autowired
    public SendMailService(JavaMailSender javaMailSender){
        this.javaMailSender = javaMailSender;
    }

    @Override
    public void SendMail(String body, String topic) {
        SimpleMailMessage mail = new SimpleMailMessage();
        mail.setFrom(MAIL_FROM);
        mail.setTo(MAIL_TO);
        mail.setSubject(topic);
        mail.setText(body);
        javaMailSender.send(mail);
    }
}
