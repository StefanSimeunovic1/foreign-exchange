package com.example.foreignexchange.domain.ports.currency;

import com.example.foreignexchange.domain.entity.Currency;

public interface FindCurrencyByIdPort {
    Currency findById(int id);
}
