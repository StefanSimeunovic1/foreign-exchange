package com.example.foreignexchange.domain.contracts.currency;

import com.example.foreignexchange.domain.entity.Currency;

public interface FindCurrencyByIdContract {
    Currency findById(int id);
}
