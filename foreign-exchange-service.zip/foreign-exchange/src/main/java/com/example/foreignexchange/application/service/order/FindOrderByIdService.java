package com.example.foreignexchange.application.service.order;

import com.example.foreignexchange.adapter.out.order.OrderJpaMapper;
import com.example.foreignexchange.domain.contracts.order.FindOrderByIdContract;
import com.example.foreignexchange.domain.entity.Order;
import com.example.foreignexchange.domain.ports.order.FindOrderByIdPort;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

@AllArgsConstructor
@Component
public class FindOrderByIdService implements FindOrderByIdContract {

    private OrderJpaMapper orderJpaMapper;
    private FindOrderByIdPort findOrderByIdPort;


    @Override
    public Order findById(int id) {
        return findOrderByIdPort.findById(id);
    }
}
