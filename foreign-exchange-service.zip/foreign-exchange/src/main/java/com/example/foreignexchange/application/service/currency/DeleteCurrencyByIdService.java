package com.example.foreignexchange.application.service.currency;

import com.example.foreignexchange.domain.contracts.currency.DeleteCurrencyByIdContract;
import com.example.foreignexchange.domain.ports.currency.DeleteCurrencyByIdPort;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

@AllArgsConstructor
@Component
public class DeleteCurrencyByIdService implements DeleteCurrencyByIdContract {

    private DeleteCurrencyByIdPort deleteCurrencyByIdPort;

    @Override
    public void deleteById(int id) {
        deleteCurrencyByIdPort.deleteById(id);
    }
}
