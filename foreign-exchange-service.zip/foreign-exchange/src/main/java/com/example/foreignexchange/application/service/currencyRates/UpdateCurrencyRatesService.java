package com.example.foreignexchange.application.service.currencyRates;

import com.example.foreignexchange.domain.contracts.currencyRates.UpdateCurrencyRatesContract;
import com.example.foreignexchange.domain.entity.CurrencyRates;
import com.example.foreignexchange.domain.ports.currencyRates.UpdateCurrencyRatePort;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

@AllArgsConstructor
@Component
public class UpdateCurrencyRatesService implements UpdateCurrencyRatesContract {

    private UpdateCurrencyRatePort updateCurrencyRatePort;

    @Override
    public void updateCurrencyRate(CurrencyRates currencyRates) {
        updateCurrencyRatePort.updateCurrencyRate(currencyRates);
    }
}
