package com.example.foreignexchange.application.service.currency;

import com.example.foreignexchange.adapter.out.currency.CurrencyJpaMapper;
import com.example.foreignexchange.domain.contracts.currency.FindCurrencyByIdContract;
import com.example.foreignexchange.domain.entity.Currency;
import com.example.foreignexchange.domain.ports.currency.FindCurrencyByIdPort;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

@AllArgsConstructor
@Component
public class FindCurrencyByIdService implements FindCurrencyByIdContract {

    private FindCurrencyByIdPort findCurrencyByIdPort;


    @Override
    public Currency findById(int id) {
        return findCurrencyByIdPort.findById(id);
    }
}
