package com.example.foreignexchange.domain.contracts.order;

import com.example.foreignexchange.domain.entity.Order;

public interface SaveOrderContract {
    Order save(Order order);
}
