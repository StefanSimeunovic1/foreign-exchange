package com.example.foreignexchange.domain.ports.currency;

import com.example.foreignexchange.domain.entity.Currency;

import java.util.List;

public interface GetAllCurrenciesPort {

    List<Currency> getAllCurrencies();
}
