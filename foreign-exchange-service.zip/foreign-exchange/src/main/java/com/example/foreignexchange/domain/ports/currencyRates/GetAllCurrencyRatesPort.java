package com.example.foreignexchange.domain.ports.currencyRates;

import com.example.foreignexchange.domain.entity.CurrencyRates;

import java.util.List;

public interface GetAllCurrencyRatesPort {
    List<CurrencyRates> getAll();
}
