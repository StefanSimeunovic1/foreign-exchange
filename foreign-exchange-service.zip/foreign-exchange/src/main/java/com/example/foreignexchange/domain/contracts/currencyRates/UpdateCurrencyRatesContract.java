package com.example.foreignexchange.domain.contracts.currencyRates;

import com.example.foreignexchange.domain.entity.CurrencyRates;

public interface UpdateCurrencyRatesContract {
    void updateCurrencyRate(CurrencyRates currencyRates);
}
