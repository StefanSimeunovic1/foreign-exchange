package com.example.foreignexchange.domain.contracts.currency;

public interface DeleteCurrencyByIdContract {
    void deleteById(int id);
}
