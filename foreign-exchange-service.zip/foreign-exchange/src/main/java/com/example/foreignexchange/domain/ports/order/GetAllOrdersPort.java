package com.example.foreignexchange.domain.ports.order;

import com.example.foreignexchange.domain.entity.Order;

import java.util.List;

public interface GetAllOrdersPort {

    List<Order> getAllOrders();
}
