package com.example.foreignexchange.application.service.currency;

import com.example.foreignexchange.adapter.out.currency.CurrencyJpaMapper;
import com.example.foreignexchange.domain.contracts.currency.SaveCurrencyContract;
import com.example.foreignexchange.domain.entity.Currency;
import com.example.foreignexchange.domain.ports.currency.SaveCurrencyPort;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

@AllArgsConstructor
@Component
public class SaveCurrencyService implements SaveCurrencyContract {

    private CurrencyJpaMapper currencyJpaMapper;
    private SaveCurrencyPort saveCurrencyPort;

    @Override
    public Currency save(Currency currency) {
        return saveCurrencyPort.save((currency));
    }
}
