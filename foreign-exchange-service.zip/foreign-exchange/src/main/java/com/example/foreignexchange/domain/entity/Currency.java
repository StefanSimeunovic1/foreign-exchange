package com.example.foreignexchange.domain.entity;

import java.util.HashSet;
import java.util.Set;

public class Currency {

    private int id;
    private String name;
    private String abbreviation;
    private String country;
    private Double fee;
    private Double discount;
    private Set<Order> orders = new HashSet<>();

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAbbreviation() {
        return abbreviation;
    }

    public void setAbbreviation(String abbreviation) {
        this.abbreviation = abbreviation;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public Double getFee() {
        return fee;
    }

    public void setFee(Double fee) {
        this.fee = fee;
    }

    public Double getDiscount() {
        return discount;
    }

    public void setDiscount(Double discount) {
        this.discount = discount;
    }

    public Set<Order> getOrders() {
        return orders;
    }

    public void setOrders(Set<Order> orders) {
        this.orders = orders;
    }

    public Currency(int id, String abbreviation, String name, String country, Double fee, Double discount) {
        this.id = id;
        this.name = name;
        this.abbreviation = abbreviation;
        this.country = country;
        this.fee = fee;
        this.discount = discount;
    }
}
