package com.example.foreignexchange.domain.ports.order;

import com.example.foreignexchange.domain.entity.Order;

public interface FindOrderByIdPort {
    Order findById(int id);
}
