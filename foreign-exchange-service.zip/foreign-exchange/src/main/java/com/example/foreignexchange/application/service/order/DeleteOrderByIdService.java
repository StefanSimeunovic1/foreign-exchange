package com.example.foreignexchange.application.service.order;

import com.example.foreignexchange.domain.contracts.currency.DeleteCurrencyByIdContract;
import com.example.foreignexchange.domain.ports.currency.DeleteCurrencyByIdPort;
import com.example.foreignexchange.domain.ports.order.DeleteOrderByIdPort;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

@AllArgsConstructor
@Component
public class DeleteOrderByIdService implements DeleteCurrencyByIdContract {

    private DeleteOrderByIdPort deleteOrderByIdPort;

    @Override
    public void deleteById(int id) {
        deleteOrderByIdPort.deleteById(id);
    }
}
