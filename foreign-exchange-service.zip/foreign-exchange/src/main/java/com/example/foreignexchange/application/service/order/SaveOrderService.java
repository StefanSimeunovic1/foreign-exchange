package com.example.foreignexchange.application.service.order;

import com.example.foreignexchange.adapter.out.order.OrderJpaMapper;
import com.example.foreignexchange.domain.contracts.order.SaveOrderContract;
import com.example.foreignexchange.domain.entity.Order;
import com.example.foreignexchange.domain.ports.order.SaveOrderPort;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

@AllArgsConstructor
@Component
public class SaveOrderService implements SaveOrderContract {

    private OrderJpaMapper orderJpaMapper;
    private SaveOrderPort saveOrderPort;


    @Override
    public Order save(Order order) {
        return saveOrderPort.save((order));
    }
}
