package com.example.foreignexchange.domain.ports.currencyRates;

import com.example.foreignexchange.domain.entity.CurrencyRates;

public interface UpdateCurrencyRatePort {
    void updateCurrencyRate(CurrencyRates currencyRates);
}
